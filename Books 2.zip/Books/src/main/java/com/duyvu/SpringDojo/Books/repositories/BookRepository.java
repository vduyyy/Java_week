package com.duyvu.SpringDojo.Books.repositories;


import java.util.*;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.duyvu.SpringDojo.Books.models.Book;

@Repository
public interface BookRepository extends CrudRepository<Book, Long>{
	List<Book> findAll();
	List<Book> findById(Integer search);
	

 
}
