package com.codingdojo.Spring.master;

public class Ninja  extends Human{
	public Ninja() {
		this.setStealth(10);
	}
	public void stealth(Human N) {
		int newHealth = N.getHealth();
		N.setHealth(newHealth - this.getStealth());
		this.setHealth(this.getHealth() + this.getStealth());
	}
	
	public void RunAway(Human N) {
		int newHealth = N.getHealth();
		this.setHealth(this.getHealth() - 10);
	}
	
}
