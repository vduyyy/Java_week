package com.codingdojo.Spring.master;

public class HumanTest {

	public static void main(String[] args) {
		Human N1 = new Human();
		Human N2 = new Human(); 
		
		//N1.attack(N2);
		
		System.out.println("Start:");
		System.out.println(N1.getHealth());
		System.out.println(N2.getHealth());

		
		Wizard Duy = new Wizard();
		
		Duy.heal(N2);
		Duy.fireball(N1);
		Duy.fireball(N2);
		
		System.out.println("Wizard:");
		System.out.println(N1.getHealth());
		System.out.println(N2.getHealth());
		
		Ninja Sara = new Ninja();
		
		Sara.stealth(N1);
		Sara.RunAway(Sara);
		System.out.println("Ninja:");
		System.out.println(N1.getHealth());
		System.out.println(Sara.getHealth());
		
		Samurai Ryan = new Samurai();
		Samurai Netra = new Samurai();
		
		
		Ryan.Deathblow(Sara);
		Ryan.Meditate(Ryan);
		
		System.out.println("Samurai");
		System.out.println(Sara.getHealth());
		System.out.println(Ryan.getHealth());
		Ryan.howMany();
	}
}
