package com.codingdojo.Spring.master;

public class Wizard extends Human {
	public Wizard() {
		this.setHealth(50);
		this.setIntelligence(8);
	}
	public void heal(Human w) {
		int newHealth = w.getHealth();
		w.setHealth(newHealth + this.getIntelligence());
	}
	public void fireball(Human w) {
		int newHealth = w.getHealth();
		w.setHealth(newHealth - (this.getIntelligence() *3));
	}
}
