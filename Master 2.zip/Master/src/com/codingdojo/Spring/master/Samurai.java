package com.codingdojo.Spring.master;

public class Samurai  extends Human{
	private static int Count= 0;
	public Samurai() {
		this.setHealth(200);
		Count ++;
	}
	public void Deathblow(Human N) {
		int newHealth = N.getHealth();
		N.setHealth(newHealth - this.getHealth());
		this.setHealth(this.getHealth()/2);
	}
	public void Meditate(Human N) {
		int newHealth = N.getHealth();
		this.setHealth(newHealth + (this.getHealth()/2 *2));
	}
	public void howMany() {
		System.out.println(Count);
	}
}


