public class FizzBuzzTest{
    public static void main(String[] args) {
        FizzBuzz Test = new FizzBuzz();
        String result = Test.fizzBuzz(15);
        
        System.out.println(result);
    }
}