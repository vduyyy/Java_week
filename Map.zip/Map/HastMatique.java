import java.util.HashMap;
import java.util.Set;

public class HastMatique{
    public static void main(String [] args){
        HashMap<String, String> usermap = new HashMap<String, String>();
        usermap.put("The Box", "Roddy Ricch");
        usermap.put("Roxanne", "Arizona Zervas");
        usermap.put("Memories", "Maroon 5");
        usermap.put("Life is Good", "Future");
        Set<String> keys = usermap.keySet();
        for (String key : keys){
            System.out.println(key);
            System.out.println(usermap.get(key));
        }
    }
}