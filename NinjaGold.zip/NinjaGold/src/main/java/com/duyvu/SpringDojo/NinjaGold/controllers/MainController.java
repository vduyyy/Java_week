package com.duyvu.SpringDojo.NinjaGold.controllers;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MainController {
	
	ArrayList<String> Activities = new ArrayList<String>();
	
	@GetMapping("/dash")
		public String index(HttpSession session, Model model) {
		Integer house = 0;
		if (session.getAttribute("gold") != null) {		
			house = (Integer) session.getAttribute("gold") + house;
//			ArrayList<String> Activities = new ArrayList<String>();
			session.setAttribute("activities", Activities);
			System.out.println("Comeonnnn"+session.getAttribute("activities"));
				
		} else {
			house = 0;
		}
		
	
		
		session.setAttribute("gold", house);
		
		
		
		
		
		return "index.jsp";
	}
	
	
	@PostMapping("/process")
		public String money(@RequestParam(value="building") String building, HttpSession session)
	{ 
			String timeStamp = new SimpleDateFormat("MMMMM dd yyyy HH:mm a").format( new Date());
			
			
			if (building.equals("Farm")) {
				Integer gold = new Random().nextInt((10+5)+5);
				Integer newgold = (Integer) session.getAttribute("gold");
				session.setAttribute("gold", gold + newgold);
				
				String act = "You entered a farm and earned "+gold+" gold.";
				//ArrayList<String> Active = (ArrayList<String>) session.getAttribute("activities");
//				@SuppressWarnings("unchecked")
				ArrayList<String> activity = (ArrayList<String>) session.getAttribute("activities");
				activity.add(act);
				//System.out.println(activity);
				System.out.println(session.getAttribute("activities"));
				session.setAttribute("activities", activity);
			
			
		
	}
			if (building.equals("House")) {
				Integer gold = new Random().nextInt((20-10)+1)+10;
				Integer newgold = (Integer) session.getAttribute("gold");
				session.setAttribute("gold", gold + newgold);
				
				String act = "You entered a House and earned "+gold+" gold.";
				//ArrayList<String> Active = (ArrayList<String>) session.getAttribute("activities");
//				@SuppressWarnings("unchecked")
				ArrayList<String> activity = (ArrayList<String>) session.getAttribute("activities");
				activity.add(act);
				//System.out.println(activity);
				System.out.println(session.getAttribute("activities"));
				session.setAttribute("activities", activity);
	}
			if (building.equals("Cave")) {
				Integer gold = new Random().nextInt((5-2)+1)+2;
				Integer newgold = (Integer) session.getAttribute("gold");
				session.setAttribute("gold", gold + newgold);
				
				
				String act = "You entered a Cave and earned "+gold+" gold.";
				//ArrayList<String> Active = (ArrayList<String>) session.getAttribute("activities");
//				@SuppressWarnings("unchecked")
				ArrayList<String> activity = (ArrayList<String>) session.getAttribute("activities");
				activity.add(act);
				//System.out.println(activity);
				System.out.println(session.getAttribute("activities"));
				session.setAttribute("activities", activity);
	}
			if (building.equals("Casino")) {
				Integer gold = new Random().nextInt((50+50)+1)-50 ;
				Integer newgold = (Integer) session.getAttribute("gold");
				session.setAttribute("gold", gold + newgold);
				
				String act = "You entered a Casino and earned "+gold+" gold.";
				//ArrayList<String> Active = (ArrayList<String>) session.getAttribute("activities");
//				@SuppressWarnings("unchecked")
				ArrayList<String> activity = (ArrayList<String>) session.getAttribute("activities");
				activity.add(act);
				//System.out.println(activity);
				System.out.println(session.getAttribute("activities"));
				session.setAttribute("activities", activity);
	}
	
			return "redirect:/dash";
			
	}	
	//@PostMapping("/reset")
	//	public String reset (HttpSession session) {
	//		HttpSession session1 = request.getSession(false);
	//		if (session!= null) {
	//			session.invalidate();
	//		}
	//}
		
			
}
