public class Theorem{
    public static void main(String[] args){
        Pythagorean squareRoot = new Pythagorean();
        double result = squareRoot.calculateHypotenuse(10, 10);
        int i = (int) result;

        System.out.println(i);
    }
}