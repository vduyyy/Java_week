
import java.util.ArrayList;
import java.util.Collections;

public class Basic{
    public void print1To255(){
        for(int a = 1; a < 256; a++){
            System.out.println(a);
        }
    }

    public void printOdd1To255(){
        for(int b = 1; b < 256; b+=2){
            System.out.println(b);
        }
    }

    public void printSum(){
        int total = 0;
        for(int c = 0; c < 256; c++){
            total += c;
            System.out.println("New number: " + c + " Sum: " + total);
        }
    }

    public void iterateArray(int[] arr){
        for(int d = 0; d < arr.length; d++){
            System.out.println(arr[d]);
        }
    }

    public void findMax(int[] arr){
        int max = arr[0];
        for(int e = 0; e < arr.length; e++){
            if(arr[e] > max){
                max = arr[e];
            }
        }
        System.out.println(max);
    }

    public void getAverage(int[] arr){
        int sum = 0;
        for(int f = 0; f < arr.length; f++){
            sum += arr[f];
        }
        System.out.println(sum/arr.length);
    }

    public void arrayOddNumbers(){
        ArrayList<Integer> y = new ArrayList<Integer>();
        for(int g = 1; g < 256; g+=2){
            y.add(g);
        }
        System.out.println(y);
    }

    public void greaterThanY(int[] arr, int y){
        int count = 0;
        for(int h = 0; h < arr.length; h++){
            if(arr[h] > y){
                count++;
            }
        }
        System.out.println(count);
    }

    public void squareTheValues(int[] x){
        ArrayList<Integer> z = new ArrayList<Integer>();
        for(int i = 0; i < x.length; i++){
            x[i] = x[i] * x[i];
            z.add(x[i]);
        }
        System.out.println(z);
    }

    public void eliminateNegativeNumbers(int[] x){
        ArrayList<Integer> newArray = new ArrayList<Integer>();
        for(int j = 0; j < x.length; j++){
            if(x[j] < 0){
                x[j] = 0;
            }
            newArray.add(x[j]);
        }
        System.out.println(newArray);
    }

    public void maxMinAvg(int[] x){
        ArrayList<Integer> newArray = new ArrayList<Integer>();
        int min = x[0];
        int max = x[0];
        int sum = 0;
        for(int k = 0; k < x.length; k++){
            if(x[k] > max){
                max = x[k];
            }
            if(x[k] < min){
                min = x[k];
            }
            sum += x[k];
        }
        int avg = sum/x.length;
        Collections.addAll(newArray, min, max, avg);
        System.out.println(newArray);
    }

    public void shiftingValues(int[] x){
        ArrayList<Integer> newArray = new ArrayList<Integer>();
        for(int l = 0; l < x.length; l++){
            if(l == x.length - 1){
                newArray.add(0);
            }
            else{
                newArray.add(x[l+1]);
            }
        }
        System.out.println(newArray);
    }
}