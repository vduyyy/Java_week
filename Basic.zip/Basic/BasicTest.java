public class BasicTest{
        public static void main(String[] args) {
        Basic testNumber = new Basic();
    
        testNumber.print1To255();
    
        testNumber.printOdd1To255();
    
        testNumber.printSum();

        int[] testArr1 = {0,1,3,5,7,9};
        testNumber.iterateArray(testArr1);
    
        int[] testArr2 = {1,3,5,7,9};
        testNumber.findMax(testArr2);
    
        int[] testArr3 = {0,1,3,5,7,9};
        testNumber.getAverage(testArr3);
    
        testNumber.arrayOddNumbers();
    
        int[] testArr4 = {0,1,3,5,7,9};
        testNumber.greaterThanY(testArr4, 3);
    
        int[] testArr5 = {0,1,3,5,7,9};
        testNumber.squareTheValues(testArr5);
    
        int[] testArr6 = {1,3,5,7,9};
        testNumber.eliminateNegativeNumbers(testArr6);
    
        int[] testArr7 = {0,1,3,5,7,9};
        testNumber.maxMinAvg(testArr7);
    
        int[] testArr8 = {0,1,3,5,7,9};
        testNumber.shiftingValues(testArr8);
    }
}