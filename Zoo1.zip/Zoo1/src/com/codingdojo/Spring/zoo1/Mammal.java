package com.codingdojo.Spring.zoo1;

public class Mammal {
	private int energyLevel = 100;
	public Mammal(){
	}
	public void setEnergy(int energyLevel) {
		this.energyLevel = energyLevel;
	}
	public int getEnergy() {
		return energyLevel;
	}
	public int displayEnergy() {
		System.out.println("The monkey energy is" + energyLevel);
		return energyLevel;
	}
}
