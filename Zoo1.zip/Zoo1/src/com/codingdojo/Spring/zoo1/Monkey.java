package com.codingdojo.Spring.zoo1;

public class Monkey extends Mammal{
	public void throwSomething() {
		this.setEnergy(this.getEnergy()-5);
		System.out.println("The monkey has throw something!");
	}
	public void eatBanana() {
		this.setEnergy(getEnergy()+10);
		System.out.println("The monkey eat banana");
	}
	public void climb() {
		this.setEnergy(getEnergy()+10);
		System.out.println("The monkey is climbing");
	}
}