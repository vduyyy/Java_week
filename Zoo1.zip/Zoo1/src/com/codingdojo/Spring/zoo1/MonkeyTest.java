package com.codingdojo.Spring.zoo1;

public class MonkeyTest {
	public static void main(String [] args) {
		Monkey m = new Monkey();
		
		m.throwSomething();
		m.displayEnergy();
		m.eatBanana();
		m.displayEnergy();
		m.climb();
		m.displayEnergy();
	}
}
