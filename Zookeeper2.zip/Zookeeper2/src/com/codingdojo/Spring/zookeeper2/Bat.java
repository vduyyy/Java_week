package com.codingdojo.Spring.zookeeper2;

public class Bat extends Mammal {
	public void fly() {
		this.setEnergy(this.getEnergyLevel()-50);
		System.out.println("The Bat is flying!" + "Wing flapping");
	}
	public void eatHumans() {
		this.setEnergy(this.getEnergyLevel()+25);
		System.out.println("The Bat is eating Human! haha");
	}
	public void attack() {
		this.setEnergy(this.getEnergyLevel()-100);
		System.out.println("The Bat attck Nester!");
	}
}
