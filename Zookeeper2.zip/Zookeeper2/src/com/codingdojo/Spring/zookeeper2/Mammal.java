package com.codingdojo.Spring.zookeeper2;

public class Mammal {
	private int EnergyLevel = 300;
	public Mammal() {	
	}
	public void setEnergy(int EnergyLevel) {
		this.EnergyLevel = EnergyLevel;
	}
	public int getEnergyLevel() {
		return EnergyLevel;
	}
	public int DisplayEnergy() {
		System.out.println("The Bat energy:" + EnergyLevel);
		return EnergyLevel;
	}
}
