package com.codingdojo.Spring.zookeeper2;

public class BatTest {
	public static void main(String [] args) {
		Bat b = new Bat();
		
		b.fly();
		b.fly();
		b.DisplayEnergy();
		b.eatHumans();
		b.eatHumans();
		b.DisplayEnergy();
		b.attack();
		b.attack();
		b.attack();
		b.DisplayEnergy();
	}
}
