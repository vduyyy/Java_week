package com.codingdojo.Spring.BankAccount;

public class BankAccount {
	private String AccountNumber;
	private double checkingBalance; 
	public double getCheckingBalance() {
		return checkingBalance;
	}

	public void setCheckingBalance(double checkingBalance) {
		this.checkingBalance = checkingBalance;
	}

	public double getSavingBalance() {
		return SavingBalance;
	}

	public void setSavingBalance(double savingBalance) {
		SavingBalance = savingBalance;
	}
	private double SavingBalance;
	private static int numberOfAccount = 0; 
	private static double numberOfAmount= 0.0;

	public BankAccount() {
		numberOfAccount ++;
		this.AccountNumber = AccountNumber();
	}
	
	public String AccountNumber() {
		String BankAccount = ""; 
		for (int i =0; i<10; i++) {
			int random = (int)(Math.random()* 10);
			BankAccount += random;
		}
		return BankAccount;
	}
	
	
	private double CheckingBalance() {
		return this.checkingBalance;
	}
	private  double SavingBalance() {
		return this.SavingBalance;
	}
	public void balance() {
		System.out.println();
	}
	public void deposit(String AccounType, double amount) {
		if(AccounType =="Checking") {
			this.checkingBalance += amount;
		}
		else if (AccounType =="Saving"){
			this.SavingBalance += amount; 
		}
		numberOfAmount += amount; 
		
		System.out.println(numberOfAmount);
	}
	public void withdraw(String AccounType, double amount) {
		if(AccounType =="Checking") {
			if(this.checkingBalance < amount) {
				System.out.println("You have no money");
				this.checkingBalance -= amount;
			}
		}
		else if (AccounType =="Saving"){
				if(this.SavingBalance < amount) {
					System.out.println("You have no money");
				this.SavingBalance -= amount; 
				}
		}
		numberOfAmount -= amount; 
	}
	
} 