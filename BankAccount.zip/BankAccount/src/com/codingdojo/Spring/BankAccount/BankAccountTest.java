package com.codingdojo.Spring.BankAccount;

public class BankAccountTest {
		public static void main(String [] args) {
			BankAccount User1 = new BankAccount();
			BankAccount User2 = new BankAccount();
			
			
			
			User1.deposit("Checking", 100);
			User2.deposit("Checking", 500);
			User2.withdraw("Checking", 600);
			

	
			System.out.println("User 1 Balance:" +User1.getCheckingBalance());
			System.out.println("User 2 Balance:" +User2.getCheckingBalance());
			
	}
		
}
