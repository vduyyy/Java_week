public class ProjectClass{
    private String name;
    private String description;
    private Integer number;

    public ProjectClass(){

    }
    public ProjectClass(String name){
        this.name=name;
    } 
    public ProjectClass(String BName, String BDescription){

    }

    public ProjectClass(Integer number){
        this.number = number;
    }
    public String getName(){
        return name;
    }
    public String getDescription(){
        return description;
    }
    public void setName(String name){
        this.name = name;
    }
    public void setDescription(String description){
        this.description = description;
    }
}