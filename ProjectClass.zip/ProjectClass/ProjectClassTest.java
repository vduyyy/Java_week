public class ProjectClassTest{
    public static void main(String[] args){
        ProjectClass A = new ProjectClass("My Project: ");
        ProjectClass B = new ProjectClass("My project: ");
        A.setName("HR");
        A.setDescription("Hiring people");
        String AName = A.getName();
        String ADescription = A.getDescription();
        System.out.println(B.getName());
        System.out.println("Project:" + AName);
        System.out.println("Project:" + AName +  "Project Description: " + ADescription);
    }
}