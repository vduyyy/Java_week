import java.util.ArrayList;

public class Exceptions{
    public static void main (String [] args){
        ArrayList<Object> myList = new ArrayList<Object>();
            myList.add("13");
            myList.add("Hello world");
            myList.add(48);
            myList.add("GoodBye World");
        try{
            for (int i=0; i<myList.size(); i++){
            Integer castedValue =(Integer) myList.get(i);
            }
        } catch (ClassCastException e ){
            System.out.print("THIS  DOES NOT WORK");
        }
    }
}