package com.duyvu.SpringDojo.ProductsCategories.services;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.duyvu.SpringDojo.ProductsCategories.models.CategoryModel;

import com.duyvu.SpringDojo.ProductsCategories.repositories.CategoryRepository;

@Service
public class CategoryService {
	private final CategoryRepository categoryrepo; 
	public CategoryService(CategoryRepository categoryrepo) {
		this.categoryrepo = categoryrepo; 
	}
	
	public CategoryModel createModel(CategoryModel categorymodel) {
		return categoryrepo.save(categorymodel);
	}
	
	public CategoryModel findOne(Long id) {
		Optional<CategoryModel> category = categoryrepo.findById(id);
		if(category.isPresent()) {
			return category.get();
		} else {
			return null; 
		}
	}


}
