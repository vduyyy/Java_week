package com.duyvu.SpringDojo.ProductsCategories.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.duyvu.SpringDojo.ProductsCategories.models.CategoryModel;
import com.duyvu.SpringDojo.ProductsCategories.models.ProductModel;
@Repository
public interface ProductsRepository  extends CrudRepository<ProductModel, Long>{
	List<ProductModel> findAll();
	
}
