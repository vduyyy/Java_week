package com.duyvu.SpringDojo.ProductsCategories.maincontroller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.duyvu.SpringDojo.ProductsCategories.models.CategoryModel;
import com.duyvu.SpringDojo.ProductsCategories.models.ProductModel;
import com.duyvu.SpringDojo.ProductsCategories.repositories.CategoryRepository;
import com.duyvu.SpringDojo.ProductsCategories.repositories.ProductsRepository;
import com.duyvu.SpringDojo.ProductsCategories.services.CategoryService;
import com.duyvu.SpringDojo.ProductsCategories.services.ProductService;

@Controller
public class MainController {
	private final ProductsRepository productrepo; 
	private final ProductService productService; 
	private final CategoryRepository categoryrepo; 
	private final CategoryService categoryService; 
	
public MainController(ProductsRepository productrepo,
					ProductService productService,
					CategoryRepository categoryrepo,
					CategoryService categoryService) {
	
		this.productrepo = productrepo; 
		this.productService = productService; 
		this.categoryrepo = categoryrepo; 
		this.categoryService = categoryService; 
	
}

		@GetMapping("/")
			public String index(Model model) {
			List<ProductModel> myproducts = productrepo.findAll();
			model.addAttribute("ProductModel", new ProductModel());
			model.addAttribute("myproducts" ,myproducts);
			return "index.jsp";
		}
	
		@PostMapping("/createProduct")
			public String product(Model model, @Valid @ModelAttribute("ProductModel") ProductModel product, BindingResult result) {
				if(result.hasErrors()) {
					return "index.jsp";
				} else {
					productService.createProduct(product);
					return "redirect:/";
				}
		}
		
		
		
		@GetMapping("/products/{ProductModel_id}")
			public String viewproduct(@PathVariable("ProductModel_id")Long id, Model model) {
				List<CategoryModel> mycategory = categoryrepo.findAll();
				ProductModel myproducts = productService.findOne(id);

				for(int i = mycategory.size() - 1; i > -1;i--) {
					if(myproducts.getCategories().contains(mycategory.get(i))) {
						mycategory.remove(i);
					}
				}
				
				model.addAttribute("ProductModel", myproducts);
				model.addAttribute("mycategory", mycategory);
				return "viewproduct.jsp";	
		}
		
		
		@PostMapping("/addCategory/{ProductModel_id}")
			public String addCategory(@PathVariable("ProductModel_id")Long productId, @RequestParam("categories") Long catId, Model model) {
			System.out.println(catId);
			ProductModel myPro = productService.findOne(productId);
			CategoryModel myCat = categoryService.findOne(catId);
			List<CategoryModel> categories = myPro.getCategories();
			categories.add(myCat);
			productService.createProduct(myPro);
			return "redirect:/products/" + productId;
		}
		
		
		
	
			
		@GetMapping("/category")
		public String category(Model model) {
		List<CategoryModel> mycategory = categoryrepo.findAll();
		model.addAttribute("CategoryModel", new CategoryModel());
		model.addAttribute("mycategory", mycategory);
		return "category.jsp";
	}
		
		
		@PostMapping("/createCategory")
		public String category(Model model, @Valid @ModelAttribute("CategoryModel") CategoryModel category, BindingResult result) {
			if(result.hasErrors()) {
				return "category.jsp";
			} else {
				categoryService.createModel(category);
				return "redirect:/category";
			}
		}
		
		@GetMapping("/category/{CategoryModel_id}")
		public String viewcategory(@PathVariable("CategoryModel_id")Long id, Model model) {
			List<ProductModel> myproduct = productrepo.findAll();
			CategoryModel mycategory = categoryService.findOne(id);

			for(int i = myproduct.size() - 1; i > -1;i--) {
				if(mycategory.getProducts().contains(myproduct.get(i))) {
					myproduct.remove(i);
				}
			}
			model.addAttribute("CategoryModel", mycategory);
			model.addAttribute("myproduct", myproduct);
			return "viewcategory.jsp";	
	}
		
		@PostMapping("/addProduct/{CategoryModel_id}")
		public String addProduct(@PathVariable("CategoryModel_id") Long CatId, @RequestParam("products")Long ProId, Model Model) {
		CategoryModel myCat = categoryService.findOne(CatId);
		ProductModel myPro = productService.findOne(ProId);
		List<ProductModel> products = myCat.getProducts();
		products.add(myPro);
		categoryService.createModel(myCat);
		return "redirect:/category/" + CatId;
	}	
		
		
		
}
