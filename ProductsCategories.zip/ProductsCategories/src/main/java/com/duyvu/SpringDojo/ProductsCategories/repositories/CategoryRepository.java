package com.duyvu.SpringDojo.ProductsCategories.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.duyvu.SpringDojo.ProductsCategories.models.CategoryModel;

@Repository
public interface CategoryRepository extends CrudRepository <CategoryModel, Long>{
	List<CategoryModel> findAll();

}
