package com.duyvu.SpringDojo.ProductsCategories.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.duyvu.SpringDojo.ProductsCategories.models.CategoryModel;
import com.duyvu.SpringDojo.ProductsCategories.models.ProductModel;
import com.duyvu.SpringDojo.ProductsCategories.repositories.CategoryRepository;
import com.duyvu.SpringDojo.ProductsCategories.repositories.ProductsRepository;
@Service
public class ProductService {
	private final ProductsRepository productrepo;
	private final CategoryRepository catergoryrepo;
	
	public ProductService(ProductsRepository productrepo,CategoryRepository catergoryrepo) {
		this.productrepo = productrepo;
		this.catergoryrepo = catergoryrepo; 
	}

	public ProductModel createProduct(ProductModel productmodel) {
		return productrepo.save(productmodel);
	}
	
	public ProductModel findOne(Long id) {
		Optional<ProductModel> product = productrepo.findById(id);
		if(product.isPresent()) {
			return product.get();
		} else {
			return null; 
		}
	}
	
	public List<ProductModel> getAll(){
		return (List<ProductModel>) productrepo.findAll();
	}
	
//	public ProductModel getProduct(Long id) {
//		List<ProductModel> products = this.getAll();
//		Optional<CategoryModel> x = CategoryRepository.findById(id);
//		if(x.isPresent()) {
//			List<ProductModel> CategoryModel = x.get().getProducts();
//			return products;
//		}else {
//			return null; 
//		}
//	}
		
}
