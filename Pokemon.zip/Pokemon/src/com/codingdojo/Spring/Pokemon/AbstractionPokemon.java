package com.codingdojo.Spring.Pokemon;

public  abstract class AbstractionPokemon  implements PokemonInterface{
	
	 public Pokemon createPokemon(String name, int health,String type){
		 return new Pokemon (name, health,type);
		 	 
	 }
	 public void Attack(Pokemon P) {
		 int newHealth = P.getHealth();
		 P.setHealth(newHealth- 15);
		 System.out.println(P.getHealth());
	 }
}