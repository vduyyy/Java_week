package com.codingdojo.Spring.Pokemon;

import java.util.ArrayList;

public class Pokedex  extends AbstractionPokemon{
	private ArrayList<Pokemon> myPokemons;
	public  void PokemonInfor(Pokemon pokemon) {
		
		System.out.println("Name:" + pokemon.getName()+"Type:"+ pokemon.getType()+ "Health:" + pokemon.getHealth());
	}
	public ArrayList<Pokemon> getMyPokemons() {
		return myPokemons;
	}
	public void setMyPokemons(ArrayList<Pokemon> myPokemons) {
		this.myPokemons = myPokemons;
	}
}
