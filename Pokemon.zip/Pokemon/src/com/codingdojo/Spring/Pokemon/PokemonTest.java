package com.codingdojo.Spring.Pokemon;

public class PokemonTest  extends Pokedex{

	public static void main(String[] args) {
		Pokedex pokedex = new Pokedex();

		Pokemon Charizard = pokedex.createPokemon("Charizard", 100, "Fire");
		Pokemon Mew = pokedex.createPokemon("Mew", 500, "GOD");
	
	
	
		pokedex.PokemonInfor(Charizard);
		//pokedex.Attack(Charizard);
		Mew.Attack(Charizard);
	
	}
	

}
