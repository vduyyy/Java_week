package com.codingdojo.Spring.Pokemon;

public interface PokemonInterface {
	Pokemon createPokemon(String name, int health, String type);
	//String pokemonInfo(Pokemon pokemon)
	void PokemonInfor(Pokemon pokemon);
	//void listPokemon(Pokemon pokemon);	
}
