package com.duyvu.SpringDojo.Books.services;


import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.duyvu.SpringDojo.Books.models.Book;
import com.duyvu.SpringDojo.Books.repositories.BookRepository;

@Service
public class BookService {
	private final BookRepository bookreport;
	
	public BookService(BookRepository bookreport) {
		this.bookreport = bookreport; 
	}
	public List<Book> allBooks() {
        return bookreport.findAll();
    }
	
	public Book findBook(Long id) {
        Optional<Book> optionalBook = bookreport.findById(id);
        if(optionalBook.isPresent()) {
            return optionalBook.get();
        } else {
            return null;
        }
    }
	
	public Book createBook(Book b) {
        return bookreport.save(b);
        
	}
	
	
	public void deleteBook(Long id) {
		Optional<Book> optionBook = bookreport.findById(id);
		if(optionBook.isPresent()) {
			bookreport.deleteById(id);
		
		}
	}
	 
	 public Book updateBook(Long id, String title, String description, String language, Integer Pages) {
			Book book = findBook(id);
			if(book.getId()== id) {
				book.setTitle(title);
				book.setDescription(description);
				book.setLangueage(language);
				book.setPages(Pages);
				bookreport.save(book);
				return createBook(book);
			}else {
				return null; 
			}
	} 

}


