package com.duyvu.SpringDojo.Books.controller;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.duyvu.SpringDojo.Books.models.Book;
import com.duyvu.SpringDojo.Books.services.BookService;


@Controller
public class Maincontroller {
		private final BookService bookService;
		public  Maincontroller(BookService bookService) {
			this.bookService = bookService;	
			
		}
		@GetMapping("/book")
		public String index(Model model){
			List<Book> books = bookService.allBooks();
			model.addAttribute("books", books);
			return "index.jsp";
		}
		
		@PostMapping(value="/createbook")
		public String create(@RequestParam(value="title") String title, 
				@RequestParam(value="description") String description,
				@RequestParam(value = "langueage") String langueage,
				@RequestParam(value="Pages") Integer Pages) {
				Book book = new Book(title, description, langueage, Pages);
				bookService.createBook(book);
				return "redirect:/book";
		
		}
		
		@GetMapping("/change/{book_id}")
		public String edit(@PathVariable("book_id") Long id, Model model){
			Book book = bookService.findBook(id);
			model.addAttribute("book", book);
			return "edit.jsp";
		}
		
		@PostMapping(value ="/edit/{book_id}") 
		public String update( @PathVariable("book_id") Long id,
				@RequestParam(value ="title") String title,
				@RequestParam(value= "description") String description,
				@RequestParam(value= "language")String language,
				@RequestParam(value ="Pages") Integer Pages) {
				bookService.updateBook(id, title, description, language, Pages);
				System.out.println("book");
				return "redirect:/book";		
		}
		
		@GetMapping("/show/{book_id}")
			public String show(@PathVariable("book_id")Long id, Model model) {
				Book book = bookService.findBook(id);
				model.addAttribute("book", book);
				return "/show.jsp";
		}
		
		 @GetMapping(value = "/delete/{book_id}")
		    public String destroy(@PathVariable("book_id") Long id) {
		        bookService.deleteBook(id);
		        return "index.jsp";
		        
		 }
		
			

}

