public class SinglyLinkedList {
    public Node head;
    public SinglyLinkedList() {
    }
    public void add(int value) {
        Node newNode = new Node(value);
        if(head == null) {
            head = newNode;
        } else {
            Node runner = head;
            while(runner.next != null) {
                runner = runner.next;
            }
            runner.next = newNode;
        }
    }
    public void printValues() {
        Node  runner = head;
        if(runner == null){
            System.out.println("You got nothing");
        }
        while (runner!= null){
            System.out.println(runner.value); 
            runner = runner.next;
        //System.out.println(runner.value);
        }
    }
    public void remove(){
        Node temp = head; 
        if (temp == null){
            System.out.println("NOTHING");
        }
        else{
            Node prev=null;
            while (temp.next != null ){
                prev = temp; 
                temp = temp.next;
                
            //System.out.println(temp);
        }
        prev.next=null;
        }

    }
}