package com.codingdojo.Spring.master;

public class Human {
	private int Strength =3;
	private int Stealth = 3;
	private int Intelligence = 3;
	private int Health = 100;
	public Human() {
		
	}
	public int getStrength() {
		return Strength;
	}
	public void setStrength(int strength) {
		Strength = strength;
	}
	public int getStealth() {
		return Stealth;
	}
	public void setStealth(int stealth) {
		Stealth = stealth;
	}
	public int getIntelligence() {
		return Intelligence;
	}
	public void setIntelligence(int intelligence) {
		Intelligence = intelligence;
	}
	public int getHealth() {
		return Health;
	}
	public void setHealth(int health) {
		Health = health;
	}
	public void DisplayHealth() {
		System.out.println("Health:" + Health);
	}
	public void attack(Human h) {
		h.Health -=Strength;
	}
}
