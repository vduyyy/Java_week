package com.codingdojo.Spring.master;

public class HumanTest {

	public static void main(String[] args) {
		Human N1 = new Human();
		Human N2 = new Human(); 
		
		N1.attack(N2);
		
		System.out.println(N1.getHealth());
		System.out.println(N2.getHealth());
	}

}
