package com.codingdojo.Spring.master;

public class Wizard extends Human {
	public  void Wizard() {
	
	}

}
