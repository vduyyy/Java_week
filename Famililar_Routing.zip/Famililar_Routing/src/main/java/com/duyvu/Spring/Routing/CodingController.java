package com.duyvu.Spring.Routing;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller

public class CodingController {
	
	
	
	@RequestMapping("/Coding")
	public String hello() {
		return "Index.jsp";
	}
	
	@RequestMapping("/python")
		public String Next() {
		return "Next.jsp";
	}
	
	@RequestMapping("/Java")
		public String Third() {
		return "Last.jsp";
	}

	@RequestMapping("/{track}")
	public String Dojo( Model model, @PathVariable("track") String track ) {
		if (track.equals("dojo")){
    		track =  "The dojo is awesome!";
    		model.addAttribute("track");
    	}
		else if (track.equals("burbank-dojo")) {
    		track = "Burbank Dojo is located in Southern California"; 
    	}
		else if (track.equals("sanjose")) {
    		track= "SJ dojo is the headquearters";		
    	}
    	return "Black.jsp" ;
	}
}
