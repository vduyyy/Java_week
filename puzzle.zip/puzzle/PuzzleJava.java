import java.util.ArrayList;
import java.util.Collections; 
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;


public class PuzzleJava{
    public static void sumAndGreaterThanY (int [] arr){
        ArrayList<Integer> newArray = new ArrayList<Integer>();
        //int [] myArray ={3,5,1,2,7,8,9,13,25,32}
        int sum = 0;
        for (int i = 0; i <arr.length; i++){
            sum += arr[i];
            if (arr[i] > 10){
                newArray.add(arr[i]);
            }
        }
        System.out.println(sum);
        System.out.println(newArray);
    }
    public static void ListString(String [] arr){
        ArrayList<String> list = new ArrayList<String>();
        ArrayList<String> List5 = new ArrayList<String>(5);
        for ( int i = 0; i < arr.length; i++){
            if (arr[i].length()> 5) {
                List5.add(arr[i]);
            }
            list.add(arr[i]);
        }
        Collections.shuffle(list);
        System.out.println(list);
    }
    public static void Alphabet(String [] arr){
        ArrayList<String> Alp = new ArrayList<String>();
        for ( char c = 'A'; c <= 'Z'; c++){
            Alp.add(Character.toString(c));
        }
        Collections.shuffle(Alp);
        System.out.println(Alp);
        System.out.println(Alp.get(0));
        System.out.println(Alp.get(25));
    }
    public static void RandomNum(String [] arr){
        ArrayList<Integer> randNum = new ArrayList<Integer>();
        int min = 101; 
        int max = 55;  
        for (int i =0; i < 10; i++){
            int num = ThreadLocalRandom.current().nextInt(55,101);
            randNum.add(num);
            if (num < min){
                min = num;
            }
            if (num > max){
                max = num;
            }
        }
        Collections.sort(randNum);
        System.out.println(randNum);
        System.out.println("Smallest:" + min);
        System.out.println("Largest:" + max);
    }
    public static void RandomString(String [] arr){
        ArrayList<String> randString4 = new ArrayList<String>();
            String character = "ABCDEFGHIJKLMNOPQRSTUVWXUZ";
            String randomString ="";
            int length = 5;
            Random rand = new Random();
            char[] randstring = new char[length];
            for ( int i =0; i < length; i++){
                randstring[i] = character.charAt(rand.nextInt(character.length()));
            }
            for (int b =0; b< randstring.length; b++){
                randomString +=randstring[b];
            }
            System.out.println(randomString);
        }
    public static void randomStringOfString(String [] arr){
        ArrayList<String> randList1 = new ArrayList<String>();
        Random rand = new Random();
        StringBuilder randString = new StringBuilder ();
        String chara = "ABCDEFGHIJKLMNOPQRSTUVWXUZ";
        for (int i = 0; i < 10; i++){
            for (int j = 0; j< 5; j++){
                randString.append(chara.charAt(rand.nextInt(chara.length())));
            }
            String lastString = randString.toString();
            randList1.add(lastString);
            randString.setLength(0);
        }
        System.out.println(randList1);

    }
}

