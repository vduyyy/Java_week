public class PuzzleTest{
    public static void main(String [] args){
        PuzzleJava testnumber = new PuzzleJava();
        int [] testArr ={3,5,1,2,7,8,9,13,25,32};
        testnumber.sumAndGreaterThanY(testArr);

        String [] teststring = {"Nancy", "Jinichi", "Fujibayashi", "Momochi", "Ishikawa"};
        testnumber.ListString(teststring);

        String [] Alpha ={};
        testnumber.Alphabet(Alpha);

        String [] randNum ={};
        testnumber.RandomNum(randNum);

        String [] randString4 = {};
        testnumber.RandomString(randString4);

        String [] randList1 = {};
        testnumber.randomStringOfString(randList1);
    }
}