package com.duyvu.Spring.Counter.MainController;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller

public class MainController {
	@GetMapping("/")
	public String index(HttpSession session, Model model){
		Integer i = 0;
		if (session.getAttribute("count") != null) {			
			i = (Integer) session.getAttribute("count") + 1;
		} else {
			i = 1;
		}
		session.setAttribute("count", i );
		model.addAttribute("count", (Integer) session.getAttribute("count"));
		return "Index.jsp";
	}
	@GetMapping("/second")
	public String secondindex(HttpSession session, Model model) {
			String n = (String) session.getAttribute("mykey");
			model.addAttribute("myvariable", n);
			return "second.jsp";	
	}
}
