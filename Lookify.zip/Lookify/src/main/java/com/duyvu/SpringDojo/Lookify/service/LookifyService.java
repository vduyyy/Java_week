package com.duyvu.SpringDojo.Lookify.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;


import com.duyvu.SpringDojo.Lookify.models.LookifyModels;
import com.duyvu.SpringDojo.Lookify.repository.LookifyRepository;

@Service
public class LookifyService {
	private final LookifyRepository lookreport;
	
	
		public LookifyService(LookifyRepository lookreport) {
			this.lookreport = lookreport; 
		}
		
		public List<LookifyModels> allLookify(){
			return lookreport.findAll();
		}
		
		public  LookifyModels createLookifyModels(LookifyModels lookify) {
			return lookreport.save(lookify);
		}
		
		public LookifyModels findlookify(Long id) {
			Optional<LookifyModels> optionalLooifyModels = lookreport.findById(id);
			if(optionalLooifyModels.isPresent()) {
				return optionalLooifyModels.get();
			}else {
				return null;
			}
		}
		
		public void deleteModel(Long id) {
			Optional<LookifyModels> lookModels = lookreport.findById(id);
			if(lookModels.isPresent()) {
				lookreport.deleteById(id);
			}
		}
			
		
}
		

