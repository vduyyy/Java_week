package com.duyvu.SpringDojo.Lookify.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.duyvu.SpringDojo.Lookify.models.LookifyModels;

@Repository
public interface LookifyRepository extends CrudRepository<LookifyModels, Long> {
	
	List<LookifyModels> findAll();
	
	List<LookifyModels> findTop10ByOrderByRateDesc();

	List<LookifyModels> findByNameContaining(String name);
	
	//List<LookifyModels> FindbyArtist(String name);

}
