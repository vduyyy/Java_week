package com.duyvu.SpringDojo.Lookify.controller;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.duyvu.SpringDojo.Lookify.models.LookifyModels;
import com.duyvu.SpringDojo.Lookify.repository.LookifyRepository;
import com.duyvu.SpringDojo.Lookify.service.LookifyService;

@Controller
public class MainController {
	private final LookifyService lookService;
	private final LookifyRepository lookRepository;

	
	public MainController(LookifyService lookService, LookifyRepository lookRepository) {
		this.lookRepository = lookRepository; 
		this.lookService = lookService;
		
	}
	
	@GetMapping("/")
		public String index() {
		return "index.jsp";
	}
	
	@GetMapping("/dashboard")
		public String dashboard(@ModelAttribute("LookifyModels") LookifyModels LookifyModels, Model model ) {
		List<LookifyModels> Lookifymodels = lookService.allLookify();
		model.addAttribute("LookifyModels", Lookifymodels);
		
		return "dashboard.jsp";
			
	}
	
	@GetMapping("/create")
		public String edit(@ModelAttribute("LookifyModels") LookifyModels lookifyModels, Model model) {
		model.addAttribute(lookifyModels);
//		model.addAttribute("errors", errors);
		return "create.jsp";
	}
	
	@PostMapping("/createsong")
		public String createsong(@Valid @ModelAttribute("LookifyModels") LookifyModels LookifyModels, BindingResult result) {
		if(result.hasErrors()) {
			return "create.jsp";
		} else {
			lookService.createLookifyModels(LookifyModels);
			return "redirect:/dashboard";
		}
	}
	@GetMapping("/show/{LookifyModels_id}")
		public String show(@PathVariable("LookifyModels_id")Long id, Model model) {
			LookifyModels lookifyModels = lookService.findlookify(id);
			model.addAttribute("LookifyModels", lookifyModels);
			return "view.jsp";
			
	}
	
	@GetMapping("/delete/{Lookifymodels_id}")
		public String delete(@PathVariable("Lookifymodels_id") Long id) {
			lookService.deleteModel(id);
			return "redirect:/dashboard";
	}
	
	
	@GetMapping("/topSong")
		public String topSong(Model model) {
			List<LookifyModels> Lookifymodels = lookRepository.findTop10ByOrderByRateDesc();
			model.addAttribute("Lookifymodels", Lookifymodels);
			return "topten.jsp";
 }
	
	@GetMapping("/search")
		public String search(String name, Model model, HttpSession session) {
			List<LookifyModels> lookifyModels = lookRepository.findByNameContaining(name);
			model.addAttribute("list", lookifyModels);
			return "search.jsp";
		
	}
	
	
	

}
