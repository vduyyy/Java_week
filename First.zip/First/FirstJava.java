public class FirstJava{
    public static void main(String[] args){
        System.out.println("My Name is Duy");
        System.out.println("I am 24 years old");
        System.out.println("My hometown is San Jose, CA");
    }
}