package com.duyvu.SpringDojo.DojoNinja.Services;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.duyvu.SpringDojo.DojoNinja.Models.DojoModels;
import com.duyvu.SpringDojo.DojoNinja.Repositories.DojoRepository;

@Service
public class DojoService {
	private final DojoRepository DojoRepo;
	
	public DojoService(DojoRepository dojoRepo) {
		this.DojoRepo = dojoRepo;
	}
	
	
	public DojoModels createDojoModels(DojoModels dojo) {
		return DojoRepo.save(dojo);
	}
	
	
	public DojoModels findOne(Long id) {
		Optional<DojoModels> x = DojoRepo.findById(id);
		if(x.isPresent()) {
			return x.get();
		} else {
			return null;
		}
	}
		
  
	public  void deleteModel(Long id) {
		Optional<DojoModels> x = DojoRepo.findById(id);
		if(x.isPresent()) {
			DojoRepo.deleteById(id);
		}
	}
	

}
