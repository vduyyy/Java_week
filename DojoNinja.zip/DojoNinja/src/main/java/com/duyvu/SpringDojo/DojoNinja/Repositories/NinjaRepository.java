package com.duyvu.SpringDojo.DojoNinja.Repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.duyvu.SpringDojo.DojoNinja.Models.NinjaModels;

@Repository 
public interface NinjaRepository  extends CrudRepository<NinjaModels, Long>{
	List <NinjaModels> findAll();

}
