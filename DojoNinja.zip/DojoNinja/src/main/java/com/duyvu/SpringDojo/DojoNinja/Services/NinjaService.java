package com.duyvu.SpringDojo.DojoNinja.Services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.duyvu.SpringDojo.DojoNinja.Models.NinjaModels;
import com.duyvu.SpringDojo.DojoNinja.Repositories.NinjaRepository;

@Service 
public class NinjaService {
	private final NinjaRepository ninjaRepo;
	public NinjaService(NinjaRepository ninjaRepo) {
		this.ninjaRepo = ninjaRepo;
	}

	
	public NinjaModels createNinjaModels(NinjaModels ninja) {
		return ninjaRepo.save(ninja);
	}
	public NinjaModels findOne(Long id) {
		Optional<NinjaModels> y = ninjaRepo.findById(id);
		if(y.isPresent()) {
			return y.get();
		} else {
			return null; 
		}
	}
	
//	public List<NinjaModels> findAllNinja(Long id) {
//		List<NinjaModels> ninjas = ninjaRepo.findById(id);
//		return ninjas;
//	}
}
