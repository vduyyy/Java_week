package com.duyvu.SpringDojo.DojoNinja.MainController;

import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.duyvu.SpringDojo.DojoNinja.Models.DojoModels;
import com.duyvu.SpringDojo.DojoNinja.Models.NinjaModels;
import com.duyvu.SpringDojo.DojoNinja.Repositories.DojoRepository;
import com.duyvu.SpringDojo.DojoNinja.Repositories.NinjaRepository;
import com.duyvu.SpringDojo.DojoNinja.Services.DojoService;
import com.duyvu.SpringDojo.DojoNinja.Services.NinjaService;

@Controller
public class MainController {
	private final DojoRepository dojoRepo; 
	private final DojoService dojoService; 
	private final NinjaRepository ninjaRepo; 
	private final NinjaService ninjaService;
	
	public MainController(DojoRepository dojoRepo, DojoService dojoService,
						NinjaRepository ninjaRepo, NinjaService ninjaService) {
		this.dojoRepo= dojoRepo;
		this.dojoService = dojoService; 
		this.ninjaRepo = ninjaRepo; 
		this.ninjaService = ninjaService; 
	}
	
	@GetMapping("/")
		public String index(Model model) {
		List<DojoModels> myDojo = dojoRepo.findAll();
		model.addAttribute("DojoModels", new DojoModels());
		model.addAttribute("myDojo", myDojo);
		return "index.jsp";
	}
	
	
	@PostMapping("/dojo")
		public String createdojo(@Valid @ModelAttribute("DojoModels") DojoModels dojo, BindingResult result) {
		if(result.hasErrors()) {
			return "index.jsp";
		} else {
			dojoService.createDojoModels(dojo);
			return "redirect:/";
		}
	}
	
	@GetMapping("/delete/{myDojo_id}")
		public String delete(@PathVariable("myDojo_id") Long id) {
		dojoService.deleteModel(id);
		return "redirect:/";
	}
	
	@GetMapping("/ninja")
		public String ninja(Model model) {
		List<DojoModels> myDojo = dojoRepo.findAll();
		model.addAttribute("NinjaModels", new NinjaModels());
		model.addAttribute("myDojo", myDojo);
		return "Ninja.jsp";
	}
	
	
	
	@PostMapping("/addNinja")
		public String createNinja(Model model, @Valid @ModelAttribute("NinjaModels") NinjaModels ninja, BindingResult result) {
		if(result.hasErrors()) {
			List<DojoModels> myDojo = dojoRepo.findAll();
			model.addAttribute("myDojo", myDojo);

			return "Ninja.jsp";
		} else {
			ninjaService.createNinjaModels(ninja);
			return "redirect:/ninja";
		}
	}
	@GetMapping("/view/{DojoModels_id}")
	public String view(@PathVariable("DojoModels_id") Long id, Model model) {
		DojoModels dojoModels = dojoService.findOne(id);
		model.addAttribute("DojoModels", dojoModels);
		
		return "showDojo.jsp";
	}
	@GetMapping("/show/{NinjaModels_id}")
		public String show(@PathVariable("NinjaModels_id")Long id, Model model) {
			NinjaModels ninjaModels = ninjaService.findOne(id);
			model.addAttribute("NinjaModels", ninjaModels);
			return "Ninjainfor.jsp";
	}
		
	
}

